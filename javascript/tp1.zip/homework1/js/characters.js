export const characters = [
  {
    firstName: "Jean",
    lastName: "Kirschtein",
    age: 20
  },
  {
    firstName: "Lukas",
    lastName: "Scripted",
    age: 45
  },
  {
    firstName: "Mikasa",
    lastName: "Ackermann",
    age: 23
  },
  {
    firstName: "Eren",
    lastName: "Jaeger",
    age: 12
  },
  {
    firstName: "Armin",
    lastName: "Arlert",
    age: 18
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
  {
    firstName: "Valentin",
    lastName: "Malo",
    age: 22,
  },
];
